import os
import urllib.parse
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from sqlalchemy import create_engine, text  # Fixed: Imported text and create_engine

# creating a FastAPI server
server = FastAPI(title='User API')

# Database configuration
mysql_url = '127.0.0.1:3306' 
mysql_user = 'root'
raw_password = os.getenv('MYSQL_ROOT_PASSWORD', '')
mysql_password = urllib.parse.quote_plus(raw_password)
database_name = 'Main'

# Fixed: Changed prefix to mysql+mysqldb to match your 'mysqlclient' requirement
connection_url = 'mysql+mysqldb://{user}:{password}@{url}/{database}'.format(
    user=mysql_user,
    password=mysql_password,
    url=mysql_url,
    database=database_name
)

mysql_engine = create_engine(connection_url)

class User(BaseModel):
    user_id: int = 0
    username: str = 'daniel'
    email: str = 'daniel@datascientest.com'

@server.get('/status')
async def get_status():
    return {'status': 1}

@server.get('/users')
async def get_users():
    with mysql_engine.connect() as connection:
        # Fixed: Wrapped query in text() and fetched rows INSIDE the with block
        query = text('SELECT * FROM Users;')
        results = connection.execute(query)
        rows = results.fetchall()
    
    return [
        User(user_id=int(i[0]), username=str(i[1]), email=str(i[2])) 
        for i in rows
    ]

@server.get('/users/{user_id}', response_model=User)
async def get_user(user_id: int):
    with mysql_engine.connect() as connection:
        # Fixed: Used bound parameters to prevent SQL injection and errors
        query = text('SELECT * FROM Users WHERE id = :user_id')
        results = connection.execute(query, {"user_id": user_id})
        row = results.fetchone()
    
    if row is None:
        raise HTTPException(status_code=404, detail='Unknown User ID')
        
    return User(user_id=int(row[0]), username=str(row[1]), email=str(row[2]))